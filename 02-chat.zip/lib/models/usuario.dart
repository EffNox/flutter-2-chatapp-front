class Usuario {
  bool online;
  String cor;
  String nom;
  String id;
  Usuario({this.online, this.cor, this.nom, this.id});
}
